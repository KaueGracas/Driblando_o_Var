extends CanvasLayer

# Tela de vitória ("BOOYAH!").
# Aparece quando todos os nós do grupo "chefoes" forem derrotados.
# Hoje estão no grupo o Robô VAR (cena_chefao) e o goleiro (cena_inimigo2).
# Para mudar quem conta como chefão, basta adicionar/remover o grupo "chefoes"
# no CharacterBody2D da cena do inimigo (aba Nó > Grupos, no editor).

var chefoes_no_inicio := 0
var venceu := false

func _ready() -> void:
	ScriptGlobal.vitoria = false
	visible = false
	$BotaoNovamente.visible = false
	$BotaoMenu.visible = false
	await get_tree().process_frame
	chefoes_no_inicio = get_tree().get_nodes_in_group("chefoes").size()

func _process(delta: float) -> void:
	if venceu:
		$Explosao.rotation += delta * 0.5
		return
	if chefoes_no_inicio == 0 or ScriptGlobal.qtd_vidas <= 0:
		return
	if get_tree().get_nodes_in_group("chefoes").is_empty():
		comemorar()

func comemorar() -> void:
	venceu = true
	ScriptGlobal.vitoria = true

	# Fim de jogo: os inimigos que sobraram (e os cartões no ar) saem de campo
	for inimigo in get_tree().get_nodes_in_group("inimigos"):
		var raiz = inimigo.get_parent()
		if raiz != get_tree().current_scene:
			raiz.queue_free()

	var musica_fase = get_tree().current_scene.get_node_or_null("AudioStreamPlayer")
	if musica_fase:
		musica_fase.stop()

	# Estado inicial da animação
	visible = true
	$Fundo.modulate.a = 0.0
	$Explosao.modulate.a = 0.0
	$Booyah.scale = Vector2.ZERO
	$Booyah.rotation = -0.35
	$Subtitulo.modulate.a = 0.0

	# 1) Apito final + escurece o fundo
	$Apito.play()
	create_tween().tween_property($Fundo, "modulate:a", 1.0, 0.6)
	await get_tree().create_timer(0.9, false).timeout

	# 2) BOOYAH! entra explodindo, com buzina e confete
	$SomBooyah.play()
	$Confete.emitting = true
	var entrada := create_tween().set_parallel(true)
	entrada.tween_property($Booyah, "scale", Vector2(0.5, 0.5), 0.55).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	entrada.tween_property($Booyah, "rotation", 0.0, 0.55).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	entrada.tween_property($Explosao, "modulate:a", 1.0, 0.4)
	await entrada.finished

	# 3) Texto pulsando + faixa "Você venceu" + música da vitória
	var pulso := create_tween().set_loops()
	pulso.tween_property($Booyah, "scale", Vector2(0.54, 0.54), 0.45).set_trans(Tween.TRANS_SINE)
	pulso.tween_property($Booyah, "scale", Vector2(0.5, 0.5), 0.45).set_trans(Tween.TRANS_SINE)
	$Musica.play()
	var destino_y: float = $Subtitulo.position.y
	$Subtitulo.position.y += 40
	var faixa := create_tween().set_parallel(true)
	faixa.tween_property($Subtitulo, "modulate:a", 1.0, 0.4)
	faixa.tween_property($Subtitulo, "position:y", destino_y, 0.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	await get_tree().create_timer(1.4, false).timeout

	# 4) Botões
	for botao in [$BotaoNovamente, $BotaoMenu]:
		botao.modulate.a = 0.0
		botao.visible = true
		create_tween().tween_property(botao, "modulate:a", 1.0, 0.4)
	$BotaoNovamente.grab_focus()

func jogar_novamente() -> void:
	ScriptGlobal.resetar_variaveis()
	get_tree().change_scene_to_file("res://cena_fase.tscn")

func ir_para_menu() -> void:
	ScriptGlobal.resetar_variaveis()
	get_tree().change_scene_to_file("res://cena_inicio.tscn")
