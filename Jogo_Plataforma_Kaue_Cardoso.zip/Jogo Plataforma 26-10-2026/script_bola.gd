extends CharacterBody2D

var direcao    = 1 #  1 => Direita, -1 => Esquerda
var velocidade = 350

func _process(delta: float) -> void:
	velocity.x = velocidade * direcao
	velocity.y = 0
	$Sprite2D.rotation += 12.0 * delta * direcao
	
	if ($RayCast2D.is_colliding()):
		var alvo = $RayCast2D.get_collider()
		if (alvo.has_method("levar_dano")):
			alvo.levar_dano(1)   # chefão: cada bola tira 1 de vida
		else:
			alvo.queue_free()    # inimigos comuns caem com uma bola
		get_parent().queue_free()
	
	move_and_slide()
	
