extends CharacterBody2D 

@export var vida_maxima = 4   # quantas bolas o chefão aguenta
@export var dano_ataque = 2   # quantas vidas cada ataque dele tira

var vida       = 4
var direcao    = 1
var gravidade  = 20
var velocidade = 300
var esta_na_tela = false

func _ready() -> void:
	vida = vida_maxima
	$BarraVida.max_value = vida_maxima
	$BarraVida.value = vida

func _process(delta: float) -> void:
	velocity.y += gravidade
	velocity.x  = 0
	if (esta_na_tela and is_on_floor() and not $Timer.is_stopped()):
		$AnimationPlayer.play("andando")
		velocity.x = velocidade * direcao

	var posx = $VisibleOnScreenNotifier2D.position.x
	if (direcao<0):
		$Sprite2D.flip_h = true
		$VisibleOnScreenNotifier2D.position.x = abs(posx) * -1
	else:
		$Sprite2D.flip_h = false
		$VisibleOnScreenNotifier2D.position.x = abs(posx)
	
	move_and_slide()

func parado() -> void:
	$Timer.stop()
	$AnimationPlayer.play("parado")

func atacar() -> void:
	$AnimationPlayer.play("atacando")
	
func voltar_andar():
	$Timer.start()
	$AnimationPlayer.play("andando")

func mudar_direcao() -> void:
	esta_na_tela = false
	direcao *= -1
	
func perseguir() -> void:
	esta_na_tela = true
	
func causar_dano_personagem():
	var personagem = ScriptGlobal.personagem
	
	if (personagem.is_on_floor() and esta_na_tela):
		ScriptGlobal.qtd_vidas -= dano_ataque

# Chamado pela bola (script_bola.gd) quando ela acerta o chefão
func levar_dano(quantidade = 1) -> void:
	vida -= quantidade
	create_tween().tween_property($BarraVida, "value", vida, 0.2)
	if (vida <= 0):
		morrer()
		return
	$SomDano.play()
	var pisca = create_tween()
	for i in 3:
		pisca.tween_property($Sprite2D, "modulate", Color(1, 0.3, 0.3), 0.06)
		pisca.tween_property($Sprite2D, "modulate", Color(1, 1, 1), 0.06)

func morrer() -> void:
	# o som continua tocando mesmo depois que o chefão sai de cena
	var som = $SomDano
	som.reparent(get_tree().current_scene)
	som.play()
	som.finished.connect(som.queue_free)
	queue_free()
